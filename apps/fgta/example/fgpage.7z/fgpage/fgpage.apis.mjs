/* API yang akan digunakan di program


	export const testapi = 'fgta/framework/formdev/nama-api'


kemdian, di program bisa diakses dengan

	$ui.apis.testapi

*/



